// scroll top button start
const toTop = document.querySelector('.to-top');

window.addEventListener("scroll",() => {
    if (window.pageYOffset > 100) {
        toTop.classList.add("active");
    }
    else{
        toTop.classList.remove("active");
    }
})
// scroll top button end

// login page scale js strat 
const bodyTag = document.querySelector('body');
const container = document.getElementById('login-full-section');
function loginpage(){
    container.style.transform = "scale(1.2)";
}
// login page scale js end 

// Buy Now prodac section start 
document.addEventListener("DOMContentLoaded", function () {
    var spinner = new ISpin(document.getElementById('number-input'), {
      wrapperClass: 'ispin-wrapper',
      buttonsClass: 'ispin-button',
      step: 1,
      pageStep: 10,
      disabled: false,
      repeatInterval: 200,
      wrapOverflow: false,
      parse: Number,
      format: String
    });
  });
// Buy Now prodac section end 
