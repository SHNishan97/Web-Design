
// menu section js start
function openFunction(){
    document.getElementById('mainbox').style.width="300px";
    
}
// menu section js end