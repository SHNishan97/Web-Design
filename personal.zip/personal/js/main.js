// header section menu actibe js
window.addEventListener('scroll', function(){
    var header = document.querySelector('header');
    header.classList.toggle('sticky',window.scrollY > 0);
})

// login page section js
function toggleForm(){
    var container = document.querySelector('.login-container');
    container.classList.toggle('active')
}